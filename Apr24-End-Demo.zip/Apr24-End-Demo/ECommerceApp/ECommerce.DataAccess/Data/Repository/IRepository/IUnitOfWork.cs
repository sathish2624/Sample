﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerce.DataAccess.Data.Repository.IRepository
{
 public   interface IUnitOfWork:IDisposable
    {
        //Unit of work reprents a single transaction or single batch
        //It will have access to the repository and a save changes method 
        //that will push the data to the database.
        ICategoryRepository Category { get; }
        void Save();
    }
}
