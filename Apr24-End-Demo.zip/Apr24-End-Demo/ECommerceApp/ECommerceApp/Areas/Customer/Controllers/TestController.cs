﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class TestController : Controller
    {
        public string Index()
        {
            return "Hello";
        }
    }
}